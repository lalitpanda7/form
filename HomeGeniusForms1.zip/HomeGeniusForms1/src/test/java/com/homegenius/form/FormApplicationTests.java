package com.homegenius.form;

import java.net.URISyntaxException;
import java.util.Optional;
import java.util.UUID;

import org.elasticsearch.action.admin.cluster.health.ClusterHealthResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.homegenius.form.bean.FileStorage;
import com.homegenius.form.bean.Form;
import com.homegenius.form.bean.FormMetadata;
import com.homegenius.form.enums.FileSizeUnit;
import com.homegenius.form.enums.FileTypeExtension;
import com.homegenius.form.enums.FormStatus;
import com.homegenius.form.enums.MimeType;
import com.homegenius.form.enums.StorageType;
import com.homegenius.form.repository.FormRepository;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.ListBlobItem;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FormApplicationTests {

	@Autowired
	private FormRepository formRepository;

	@Autowired
	private CloudStorageAccount cloudStorageAccount;

	@Autowired
	private ElasticsearchTemplate elasticsearchTemplate;

	@Test
	public void testFormCreation() {
		ClusterHealthResponse response = elasticsearchTemplate.getClient().admin().cluster().prepareHealth().get();
		System.out.println(response.toString());

		FileStorage fileStorage = new FileStorage();
		fileStorage.setLink("www.google.com");
		fileStorage.setStorageKey("storagekey");
		fileStorage.setStorageType(StorageType.AZURE_BLOB);

		FormMetadata formMetadata = new FormMetadata();
		formMetadata.setEncrypted(false);
		formMetadata.setFileSize(300);
		formMetadata.setFileSizeUnit(FileSizeUnit.KB);
		formMetadata.setFileTypeExtension(FileTypeExtension.PDF);
		formMetadata.setMimeType(MimeType.APPLICATION_PDF);
		formMetadata.setPageCount(10);
		formMetadata.setFileName("Addendum Concerning Right to Terminate Due to Lender's Appraisal (TREC No. 49-0)");

		Form form = new Form();
		form.setId(UUID.randomUUID().toString());
		form.setDeleted(false);
		form.setDescription("TREC No. 49-0");
		form.setFileStorage(fileStorage);
		form.setFormMetadata(formMetadata);
		form.setFormStatus(FormStatus.ONLINE);
		form.setName("Addendum Concerning Right to Terminate Due to Lender's Appraisal");
		form.setReadOnly(false);

		formRepository.save(form);

		Optional<Form> optinal = formRepository.findById(form.getId());
		System.out.println(optinal.get().getName());
	}

	@Test
	public void testBlobStorage() {

		try {
			// Create the blob client.
			final CloudBlobClient blobClient = cloudStorageAccount.createCloudBlobClient();

			// Retrieve reference to a previously created container.
			final CloudBlobContainer container = blobClient.getContainerReference("users-documents");

			// Loop over blobs within the container and output the URI to each of them.
			for (final ListBlobItem blobItem : container.listBlobs()) {
				System.out.println(blobItem.getUri());
			}
		} catch (StorageException | URISyntaxException e) {
			e.printStackTrace();
		}

	}

}