package com.homegenius.form.exception;

public class NonFatalException extends Exception {

	private static final long serialVersionUID = 1L;

	private String errorCode;

	public NonFatalException() {
		super();
	}

	public NonFatalException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public NonFatalException(String errorCode, String message, Throwable thrw) {
		super(message, thrw);
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
