package com.homegenius.form;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormApplication {

	/**
	 * Static logger for the class
	 */
	private static final Logger log = LoggerFactory.getLogger(FormApplication.class);

	public static void main(String[] args) {
		log.info("Starting spring boot applicaion main method");
		SpringApplication.run(FormApplication.class, args);
	}

}