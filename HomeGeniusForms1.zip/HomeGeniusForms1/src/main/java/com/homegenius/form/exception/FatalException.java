package com.homegenius.form.exception;

public class FatalException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String errorCode;

	public FatalException() {
		super();
	}

	public FatalException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public FatalException(String errorCode, String message, Throwable thrw) {
		super(message, thrw);
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
