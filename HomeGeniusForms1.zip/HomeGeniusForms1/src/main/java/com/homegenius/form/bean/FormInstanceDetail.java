package com.homegenius.form.bean;

public class FormInstanceDetail {

	private String formFields;
	private String formFieldsData;

	public String getFormFields() {
		return formFields;
	}

	public void setFormFields(String formFields) {
		this.formFields = formFields;
	}

	public String getFormFieldsData() {
		return formFieldsData;
	}

	public void setFormFieldsData(String formFieldsData) {
		this.formFieldsData = formFieldsData;
	}

	@Override
	public String toString() {
		return "FormInstanceDetail [formFields=" + formFields + ", formFieldsData=" + formFieldsData + "]";
	}

}
