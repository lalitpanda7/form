package com.homegenius.form.enums;

public enum MimeType {
	APPLICATION_PDF("application/pdf"), APPLICATION_XML("application/xml"), APPLICATION_ZIP(
			"application/zip"), IMAGE_GIF("image/gif"), IMAGE_JPEG("image/jpeg"), TEXT_HTML("text/html");

	private String value;

	MimeType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
