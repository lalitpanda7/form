package com.homegenius.form.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.homegenius.form.bean.FormMetadata;
import com.homegenius.form.enums.FileSizeUnit;
import com.homegenius.form.enums.FileTypeExtension;
import com.homegenius.form.enums.MimeType;
import com.homegenius.form.exception.FileStorageException;

@Component
public class AppUtils {

	/**
	 * Method to get FormMetadata from MultipartFile
	 * 
	 * @param multipartFile
	 * @return
	 * @throws IOException
	 */
	public static FormMetadata getFileMetadata(MultipartFile multipartFile) throws IOException {

		// Normalize file name
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());

		// Check if the file's name contains invalid characters and if it is null
		if (fileName.contains("..")) {
			throw new FileStorageException("Invalid file input");
		}

		InputStream inputStream = multipartFile.getInputStream();
		PDDocument document = PDDocument.load(inputStream);

		// Populate FormMetadata
		FormMetadata formMetadata = new FormMetadata();
		formMetadata.setEncrypted(document.isEncrypted());
		formMetadata.setFileSize(multipartFile.getSize());
		formMetadata.setFileSizeUnit(FileSizeUnit.B);
		formMetadata.setFileTypeExtension(FileTypeExtension.PDF);
		formMetadata.setMimeType(MimeType.APPLICATION_PDF);
		formMetadata.setPageCount(document.getNumberOfPages());

		// Close the document
		document.close();
		return formMetadata;

	}
}
