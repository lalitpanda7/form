package com.homegenius.form.enums;

public enum FormCategory {

	LEASE("Lease"), LISTING("Listing"), PURCHASE("Purchase"), PROPERTY_MANAGEMENT("Property Management"), VACANT_LAND(
			"Vacant Land"), FORM_UPDATE_6_18("Form Update for 6/18"), FORM_UPDATE_12_17(
					"Form Update for 12/17"), DISCLOSURE("Disclosure"), COMMERCIAL(
							"Commercial"), BACK_OFFICE("Back Office"), NO_CATEGORY("No Category");

	private String value;

	FormCategory(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
