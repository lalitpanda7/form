package com.homegenius.form.bean;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import com.homegenius.form.enums.FormStatus;

@org.springframework.data.elasticsearch.annotations.Document(indexName = "forms", createIndex = false)
public class Form {

	@Id
	private String id;
	private String name;
	private String description;
	private DateTime createdOn;
	private DateTime updatedOn;
	private String createdBy;
	private String updatedBy;
	private boolean isReadOnly;
	private boolean isDeleted;
	private FormStatus formStatus;
	private List<String> mlsList;
	private List<String> formCategoryList;

	@Field(type = FieldType.Nested)
	private FileStorage fileStorage;

	@Field(type = FieldType.Nested)
	private FormMetadata formMetadata;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public DateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}

	public DateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(DateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public boolean isReadOnly() {
		return isReadOnly;
	}

	public void setReadOnly(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public FormStatus getFormStatus() {
		return formStatus;
	}

	public void setFormStatus(FormStatus formStatus) {
		this.formStatus = formStatus;
	}

	public List<String> getMlsList() {
		return mlsList;
	}

	public void setMlsList(List<String> mlsList) {
		this.mlsList = mlsList;
	}

	public List<String> getFormCategoryList() {
		return formCategoryList;
	}

	public void setFormCategoryList(List<String> formCategoryList) {
		this.formCategoryList = formCategoryList;
	}

	public FileStorage getFileStorage() {
		return fileStorage;
	}

	public void setFileStorage(FileStorage fileStorage) {
		this.fileStorage = fileStorage;
	}

	public FormMetadata getFormMetadata() {
		return formMetadata;
	}

	public void setFormMetadata(FormMetadata formMetadata) {
		this.formMetadata = formMetadata;
	}

	@Override
	public String toString() {
		return "Form [id=" + id + ", name=" + name + ", description=" + description + ", createdOn=" + createdOn
				+ ", updatedOn=" + updatedOn + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", isReadOnly="
				+ isReadOnly + ", isDeleted=" + isDeleted + ", formStatus=" + formStatus + ", mlsList=" + mlsList
				+ ", formCategoryList=" + formCategoryList + ", fileStorage=" + fileStorage + ", formMetadata="
				+ formMetadata + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((fileStorage == null) ? 0 : fileStorage.hashCode());
		result = prime * result + ((formCategoryList == null) ? 0 : formCategoryList.hashCode());
		result = prime * result + ((formMetadata == null) ? 0 : formMetadata.hashCode());
		result = prime * result + ((formStatus == null) ? 0 : formStatus.hashCode());
		result = prime * result + (isDeleted ? 1231 : 1237);
		result = prime * result + (isReadOnly ? 1231 : 1237);
		result = prime * result + ((mlsList == null) ? 0 : mlsList.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Form other = (Form) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (fileStorage == null) {
			if (other.fileStorage != null)
				return false;
		} else if (!fileStorage.equals(other.fileStorage))
			return false;
		if (formCategoryList == null) {
			if (other.formCategoryList != null)
				return false;
		} else if (!formCategoryList.equals(other.formCategoryList))
			return false;
		if (formMetadata == null) {
			if (other.formMetadata != null)
				return false;
		} else if (!formMetadata.equals(other.formMetadata))
			return false;
		if (formStatus != other.formStatus)
			return false;
		if (isDeleted != other.isDeleted)
			return false;
		if (isReadOnly != other.isReadOnly)
			return false;
		if (mlsList == null) {
			if (other.mlsList != null)
				return false;
		} else if (!mlsList.equals(other.mlsList))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}