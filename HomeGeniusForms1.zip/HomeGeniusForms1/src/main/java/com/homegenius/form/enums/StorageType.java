package com.homegenius.form.enums;

public enum StorageType {

	AZURE_BLOB("Azure Blob"), FILE_SYSTEM("File System"), S3("S3");

	private String value;

	StorageType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
