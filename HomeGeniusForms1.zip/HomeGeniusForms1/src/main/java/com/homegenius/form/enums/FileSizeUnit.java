package com.homegenius.form.enums;

public enum FileSizeUnit {
	B("B"), KB("KB"), MB("MB"), GB("GB");

	private String value;

	FileSizeUnit(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
