package com.homegenius.form.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class RequestLoggingFilterConfig {

	/**
	 * Static logger for the class
	 */
	private final Logger log = LoggerFactory.getLogger(RequestLoggingFilterConfig.class);

	@Bean
	public CommonsRequestLoggingFilter logFilter() {

		log.debug("Method: logFilter started");

		CommonsRequestLoggingFilter filter = new CommonsRequestLoggingFilter();
		filter.setIncludeQueryString(true);
		filter.setIncludePayload(true);
		filter.setIncludeHeaders(true);

		log.debug("Method: logFilter finished");
		return filter;
	}

}