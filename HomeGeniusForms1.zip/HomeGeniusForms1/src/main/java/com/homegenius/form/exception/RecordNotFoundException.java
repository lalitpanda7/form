package com.homegenius.form.exception;

public class RecordNotFoundException extends NonFatalException {

	private static final long serialVersionUID = 1L;

	public RecordNotFoundException(String errorCode, String message) {
		super(errorCode, message);
	}

	public RecordNotFoundException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

}
