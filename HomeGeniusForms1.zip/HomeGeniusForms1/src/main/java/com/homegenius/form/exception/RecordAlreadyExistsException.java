package com.homegenius.form.exception;

public class RecordAlreadyExistsException extends NonFatalException {

	private static final long serialVersionUID = 1L;

	public RecordAlreadyExistsException(String errorCode, String message) {
		super(errorCode, message);
	}

	public RecordAlreadyExistsException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

}
