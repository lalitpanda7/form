package com.homegenius.form.bean;

import java.util.Date;

import org.joda.time.DateTime;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@org.springframework.data.elasticsearch.annotations.Document(indexName = "forms", type = "form", createIndex = false)
public class FormInstance {

	@Id
	private String id;
	private String name;
	private String description;
	private DateTime createdOn;
	private DateTime updatedOn;
	private String createdBy;
	private String updatedBy;
	private String parentFormId;
	private String workflowId;
	private String taskId;
	private Date dueDate;
	private String previewLink;
	private FileStorage fileStorage;
	private boolean isDeleted;
	private boolean isInstance = true;

	@Field(type = FieldType.Nested)
	private FormMetadata formMetadata;

	@Field(type = FieldType.Nested)
	private FormInstanceDetail formInstanceDetail;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public DateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}

	public DateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(DateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getParentFormId() {
		return parentFormId;
	}

	public void setParentFormId(String parentFormId) {
		this.parentFormId = parentFormId;
	}

	public String getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(String workflowId) {
		this.workflowId = workflowId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPreviewLink() {
		return previewLink;
	}

	public void setPreviewLink(String previewLink) {
		this.previewLink = previewLink;
	}

	public FileStorage getFileStorage() {
		return fileStorage;
	}

	public void setFileStorage(FileStorage fileStorage) {
		this.fileStorage = fileStorage;
	}

	public FormMetadata getFormMetadata() {
		return formMetadata;
	}

	public void setFormMetadata(FormMetadata formMetadata) {
		this.formMetadata = formMetadata;
	}

	public FormInstanceDetail getFormInstanceDetail() {
		return formInstanceDetail;
	}

	public void setFormInstanceDetail(FormInstanceDetail formInstanceDetail) {
		this.formInstanceDetail = formInstanceDetail;
	}

	public boolean isInstance() {
		return isInstance;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	@Override
	public String toString() {
		return "FormInstance [id=" + id + ", name=" + name + ", description=" + description + ", createdOn=" + createdOn
				+ ", updatedOn=" + updatedOn + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ ", parentFormId=" + parentFormId + ", workflowId=" + workflowId + ", taskId=" + taskId + ", dueDate="
				+ dueDate + ", previewLink=" + previewLink + ", fileStorage=" + fileStorage + ", isDeleted=" + isDeleted
				+ ", isInstance=" + isInstance + ", formMetadata=" + formMetadata + ", formInstanceDetail="
				+ formInstanceDetail + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((dueDate == null) ? 0 : dueDate.hashCode());
		result = prime * result + ((fileStorage == null) ? 0 : fileStorage.hashCode());
		result = prime * result + ((formInstanceDetail == null) ? 0 : formInstanceDetail.hashCode());
		result = prime * result + ((formMetadata == null) ? 0 : formMetadata.hashCode());
		result = prime * result + (isDeleted ? 1231 : 1237);
		result = prime * result + (isInstance ? 1231 : 1237);
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((parentFormId == null) ? 0 : parentFormId.hashCode());
		result = prime * result + ((previewLink == null) ? 0 : previewLink.hashCode());
		result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
		result = prime * result + ((workflowId == null) ? 0 : workflowId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FormInstance other = (FormInstance) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (dueDate == null) {
			if (other.dueDate != null)
				return false;
		} else if (!dueDate.equals(other.dueDate))
			return false;
		if (fileStorage == null) {
			if (other.fileStorage != null)
				return false;
		} else if (!fileStorage.equals(other.fileStorage))
			return false;
		if (formInstanceDetail == null) {
			if (other.formInstanceDetail != null)
				return false;
		} else if (!formInstanceDetail.equals(other.formInstanceDetail))
			return false;
		if (formMetadata == null) {
			if (other.formMetadata != null)
				return false;
		} else if (!formMetadata.equals(other.formMetadata))
			return false;
		if (isDeleted != other.isDeleted)
			return false;
		if (isInstance != other.isInstance)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (parentFormId == null) {
			if (other.parentFormId != null)
				return false;
		} else if (!parentFormId.equals(other.parentFormId))
			return false;
		if (previewLink == null) {
			if (other.previewLink != null)
				return false;
		} else if (!previewLink.equals(other.previewLink))
			return false;
		if (taskId == null) {
			if (other.taskId != null)
				return false;
		} else if (!taskId.equals(other.taskId))
			return false;
		if (workflowId == null) {
			if (other.workflowId != null)
				return false;
		} else if (!workflowId.equals(other.workflowId))
			return false;
		return true;
	}

}