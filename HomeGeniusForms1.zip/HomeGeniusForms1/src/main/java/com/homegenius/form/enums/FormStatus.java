package com.homegenius.form.enums;

public enum FormStatus {

	DRAFT("Draft"), REVIEWED("Reviewed"), ONLINE("Online"), OFFLINE("Offline");

	private String value;

	FormStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
