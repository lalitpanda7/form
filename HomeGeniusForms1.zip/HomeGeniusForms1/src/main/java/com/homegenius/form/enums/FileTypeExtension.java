package com.homegenius.form.enums;

public enum FileTypeExtension {
	PDF("pdf"), DOC("doc"), DOCS("docs"), JPG("jpg"), PNG("png"), JPEG("jpeg"), TXT("txt");

	private String value;

	FileTypeExtension(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
