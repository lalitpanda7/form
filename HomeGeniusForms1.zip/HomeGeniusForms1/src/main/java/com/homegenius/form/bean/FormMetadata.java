package com.homegenius.form.bean;

import com.homegenius.form.enums.FileSizeUnit;
import com.homegenius.form.enums.FileTypeExtension;
import com.homegenius.form.enums.MimeType;

public class FormMetadata {

	private boolean isEncrypted;
	private long fileSize;
	private String fileName;
	private FileSizeUnit fileSizeUnit;
	private FileTypeExtension fileTypeExtension;
	private MimeType mimeType;
	private int pageCount;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean isEncrypted() {
		return isEncrypted;
	}

	public void setEncrypted(boolean isEncrypted) {
		this.isEncrypted = isEncrypted;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public FileSizeUnit getFileSizeUnit() {
		return fileSizeUnit;
	}

	public void setFileSizeUnit(FileSizeUnit fileSizeUnit) {
		this.fileSizeUnit = fileSizeUnit;
	}

	public FileTypeExtension getFileTypeExtension() {
		return fileTypeExtension;
	}

	public void setFileTypeExtension(FileTypeExtension fileTypeExtension) {
		this.fileTypeExtension = fileTypeExtension;
	}

	public MimeType getMimeType() {
		return mimeType;
	}

	public void setMimeType(MimeType mimeType) {
		this.mimeType = mimeType;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	@Override
	public String toString() {
		return "FormMetadata [isEncrypted=" + isEncrypted + ", fileSize=" + fileSize + ", fileSizeUnit=" + fileSizeUnit
				+ ", fileTypeExtension=" + fileTypeExtension + ", mimeType=" + mimeType + ", pageCount=" + pageCount
				+ "]";
	}

}
